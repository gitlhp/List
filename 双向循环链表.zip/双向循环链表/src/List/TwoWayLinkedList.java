package List;

import java.util.Scanner;

public class TwoWayLinkedList <AnyType>{
	public TwoWayLinkedListNode<AnyType> firstNode;
	public TwoWayLinkedList(){
		firstNode=null;
	}
	public boolean insertINode(int i,AnyType data){
		if(i==1){
			insertFirstNode(data);
			return true;
		}
		else {
		TwoWayLinkedListNode<AnyType> p=firstNode;
		int j=0;
		for(j=0;j<i-1&&p!=null;j++){
			p=p.next;
		}
		if(j==i-1){
		TwoWayLinkedListNode<AnyType> q=p.pre;
		TwoWayLinkedListNode<AnyType> tmp=new TwoWayLinkedListNode(data,null,null);
		q.next=tmp;
		tmp.pre=q;
		tmp.next=p;
		p.pre=tmp;
		return true;
		}
		else {
			System.out.println("���볬����Χ");
			return false;
		}
	  }
	}
	public boolean deleteINode(int i){
		if(i==1){
			TwoWayLinkedListNode<AnyType> p=firstNode;
			p.pre.next=p.next;
			p.next.pre=p.pre;
			firstNode=p.next;
			return true;
		}
		else {
		TwoWayLinkedListNode<AnyType> p=firstNode;
		int j=0;
		for(j=0;j<i-1&&p!=null;j++){
			p=p.next;
		}
		if(j==i-1){
			TwoWayLinkedListNode<AnyType> q=p.pre;
			q.next=p.next;
			p.next.pre=q;
			return true;
		}
		else {
			System.out.println("ɾ����Ԫ�ز�����");
			return false;
		}
		}
	}
	public void insertFirstNode(AnyType data){
		TwoWayLinkedListNode<AnyType> p=firstNode;
		TwoWayLinkedListNode<AnyType> tmp=new TwoWayLinkedListNode<AnyType>(data,p.pre,p);
		p.pre.next=tmp;
		p.pre=tmp;
		firstNode=tmp;
	}
	public void insertLastNode(AnyType data){
		TwoWayLinkedListNode<AnyType> p=firstNode;
		TwoWayLinkedListNode<AnyType> q=p.pre;
		TwoWayLinkedListNode<AnyType> tmp=new TwoWayLinkedListNode(data,q,p);
		q.next=tmp;
		p.pre=tmp;
	}
	public void add(AnyType data){
		TwoWayLinkedListNode<AnyType> p=firstNode;
		if(p==null){
			TwoWayLinkedListNode<AnyType> tmp=new TwoWayLinkedListNode<AnyType>(data,null,null);
			tmp.pre=tmp;
			tmp.next=tmp;
			firstNode=tmp;
		}
		else{
			insertLastNode(data);
		}
	}
	public void reverse(){
		TwoWayLinkedListNode<AnyType> p=firstNode;
		TwoWayLinkedListNode<AnyType> q=p.pre;
		TwoWayLinkedList<AnyType> first=new TwoWayLinkedList();
		while(q!=firstNode){
			first.add(q.data);
			q=q.pre;
		}
		first.add(q.data);
		this.firstNode=first.firstNode;
	}
	public void print(){
		TwoWayLinkedListNode<AnyType> p=firstNode;
		System.out.print(p.data+" ");
		p=p.next;
		while(p!=firstNode){
			System.out.print(p.data+" ");
			p=p.next;
		}
		System.out.println();
	}
	/*public static void main(String args[]){
		TwoWayLinkedList<Integer> my=new TwoWayLinkedList();
		int len,a;
		System.out.println("�����������ĳ��ȣ�");
		Scanner cin=new Scanner(System.in);
		len=cin.nextInt();
		System.out.println("�����������ĸ����㣺");
		for(int i=0;i<len;i++){
			a=cin.nextInt();
			my.add(a);
		}
		int pos,val;
		System.out.println("������Ҫ����ĵ��λ�ú�ֵ��");
		pos=cin.nextInt();
		val=cin.nextInt();
		my.insertINode(pos+1,val);
		System.out.println("������˳���ǣ�");
		my.print();
		System.out.println("������Ҫɾ����λ�ã�");
		pos=cin.nextInt();
		System.out.println("������˳���ǣ�");
		my.deleteINode(pos+1);
		my.print();
		System.out.println("������Ҫ�����һ�������ֵ��");
		val=cin.nextInt();
		my.insertFirstNode(val);
		System.out.println("������˳���ǣ�");
		my.print();
		System.out.println("������Ҫ�������һ�������ֵ��");
		val=cin.nextInt();
		my.insertLastNode(val);
		System.out.println("������˳���ǣ�");
		my.print();
		my.reverse();
		System.out.println("�͵���ת֮���������˳���ǣ�");
		my.print();
	}*/
}