package List;

import java.util.Scanner;

public class danlianbiao{
	
	  public void  danlianbiao(int a[]){
		  int i,j;
		  int tmp;
		  for(i=0;i<a.length;i++){
			  for(j=i;j<a.length;j++){
				  if(a[i]>a[j]){
					  tmp=a[i];
					  a[i]=a[j];
					  a[j]=tmp;
				  }
			  }
		  } 
	  }
public static void main(String[] args){
	Scanner sc=new Scanner(System.in);
	danlianbiao n=new danlianbiao();
	System.out.print("�����룺");
	int k=sc.nextInt();
	int[] num=new int[k];	
	for(int i=0;i<k;i++){
		num[i]=(int)sc.nextInt();
	}
    //int m[]={1,4,6,7,3,2,88};
	n.danlianbiao(num);
	System.out.print("�����");
	for(int i=0;i<k;i++){
		System.out.print(num[i]+" ");
	}
}


}