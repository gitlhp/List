package List;

public class TwoWayLinkedListNode<AnyType> {
	AnyType data;
	TwoWayLinkedListNode<AnyType> pre;
	TwoWayLinkedListNode<AnyType> next;
	public TwoWayLinkedListNode(AnyType data,TwoWayLinkedListNode<AnyType> pre,TwoWayLinkedListNode<AnyType> next){
		this.data=data;
		this.pre=pre;
		this.next=next;
	}
}